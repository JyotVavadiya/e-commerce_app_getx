import 'package:flutter/cupertino.dart';

 Color black = Color(0xff000000);
 Color bgColor = Color(0xffebeaef);